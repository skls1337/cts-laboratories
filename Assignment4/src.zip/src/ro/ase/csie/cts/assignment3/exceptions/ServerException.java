package ro.ase.csie.cts.assignment3.exceptions;

public class ServerException extends Exception {

}
