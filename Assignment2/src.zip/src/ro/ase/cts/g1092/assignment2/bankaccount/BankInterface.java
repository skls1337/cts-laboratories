package ro.ase.cts.g1092.assignment2.bankaccount;

public interface BankInterface {
	static final float BROKER_FEE = 0.125f;
	static final int NO_DAYS_PER_YEAR = 365;
}
