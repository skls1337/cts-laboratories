package ro.ase.cts.test.builder;

public enum DificultateCurs {
	INCEPATOR,MEDIU,AVANSAT
}
