package grecu.andy.g1092.builder;

public enum StudyYearEnum {
	FIRST_YEAR,SECOND_YEAR,THIRD_YEARD,SUPLEMENTARY_YEAR
}
