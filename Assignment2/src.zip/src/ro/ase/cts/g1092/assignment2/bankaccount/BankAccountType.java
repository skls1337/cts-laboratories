package ro.ase.cts.g1092.assignment2.bankaccount;

public enum BankAccountType {
	STANDARD,BUDGET,PREMIUM,SUPER_PREMIUM;
}
