package cts.grecu.andy.g1092.factory;

public enum AccountType {
	DEBIT,CREDIT,JUNIOR
}
