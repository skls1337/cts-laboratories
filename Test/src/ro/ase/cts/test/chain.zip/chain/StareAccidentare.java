package ro.ase.cts.test.chain;

public enum StareAccidentare {
	NEACCIDENTAT,USOR_ACCIDENTAT,ACCIDENTAT,GRAV_ACCIDENTAT
}
