package ro.ase.csie.cts.g1092.testing.exceptions;

public class DivisionByZeroException extends Exception{

}
