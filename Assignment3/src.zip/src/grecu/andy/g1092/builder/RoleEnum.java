package grecu.andy.g1092.builder;

public enum RoleEnum {
	STUDENT,PROFESSOR
}
